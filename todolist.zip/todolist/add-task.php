<?php
header('Content-Type: application/json');

// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "todolist";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    echo json_encode(["error" => "Connection failed: " . $conn->connect_error]);
    exit();
}

// Get data from POST request
$data = json_decode(file_get_contents('php://input'), true);

if (json_last_error() !== JSON_ERROR_NONE) {
    echo json_encode(["error" => "Invalid JSON input"]);
    exit();
}

$title = $data['title'] ?? '';
$note = $data['note'] ?? '';
$date = $data['date'] ?? '';
$timeStart = $data['timeStart'] ?? '';
$timeEnd = $data['timeEnd'] ?? '';
$remind = $data['remind'] ?? '';
$repeat = $data['repeat'] ?? '';
$color = $data['color'] ?? '';
$status = 'Pending'; // Set default status to 'Pending'

// Prepare and bind
$stmt = $conn->prepare("INSERT INTO todo_tasks (title, note, date, time_start, time_end, remind, `repeat`, color, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
if ($stmt === false) {
    echo json_encode(["error" => "Prepare failed: " . $conn->error]);
    exit();
}

$stmt->bind_param("sssssssss", $title, $note, $date, $timeStart, $timeEnd, $remind, $repeat, $color, $status);

if ($stmt->execute()) {
    echo json_encode(["message" => "Task added successfully"]);
} else {
    echo json_encode(["error" => "Error: " . $stmt->error]);
}

$stmt->close();
$conn->close();
?>
