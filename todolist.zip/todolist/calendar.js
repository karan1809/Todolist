document.addEventListener('DOMContentLoaded', function () {
    const calendarGrid = document.getElementById('calendar-grid');
    const monthYearSpan = document.getElementById('month-year');
    const prevMonthBtn = document.getElementById('prev-month');
    const nextMonthBtn = document.getElementById('next-month');

    let currentMonth = new Date().getMonth();
    let currentYear = new Date().getFullYear();

    // Function to load tasks
// Function to load tasks
// Function to load tasks
// Function to load tasks
function loadTasks(date) {
    console.log('Fetching tasks for date (JS):', date); // Log the date being sent to fetch
    fetch('fetch-tasks.php?date=' + date)
        .then(response => response.json())
        .then(tasks => {
            console.log('Tasks (JS):', tasks); // Log the fetched tasks
            const taskList = document.getElementById('taskList');
            taskList.innerHTML = ''; // Clear existing tasks

            tasks.forEach(task => {
                const taskItem = document.createElement('div');
                taskItem.className = 'task-item';
                const color = task.color ? task.color : 'white';
                taskItem.style.backgroundColor = color;

                // Create task content
                taskItem.innerHTML = `
                    <h3>${task.title}</h3>
                    <p><span class="time">&#128337; ${task.time_start} - ${task.time_end}</span></p>
                    <p>${task.note}</p>
                    <div class="task-buttons">
                        <button class="complete-btn">Complete Task</button>
                        <button class="delete-btn">Delete Task</button>
                    </div>
                `;

                // Append task item to the task list
                taskList.appendChild(taskItem);

                // Add event listeners for the buttons
                const completeBtn = taskItem.querySelector('.complete-btn');
                const deleteBtn = taskItem.querySelector('.delete-btn');

                // Show or hide buttons based on status
                if (task.status === 'Completed') {
                    completeBtn.style.display = 'none'; // Hide the complete button
                    deleteBtn.style.display = 'block';  // Show the delete button
                } else {
                    completeBtn.style.display = 'block'; // Show the complete button
                    deleteBtn.style.display = 'block';  // Show the delete button
                }

                completeBtn.addEventListener('click', function() {
                    updateTaskStatus(task.id, 'Completed'); // Function to update task status
                });

                deleteBtn.addEventListener('click', function() {
                    deleteTask(task.id); // Function to delete task
                });
            });
        })
        .catch(error => console.error('Error fetching tasks:', error));
}


// Function to update task status
function updateTaskStatus(taskId, status) {
    fetch('update-task-status.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ id: taskId, status: status }),
    })
    .then(response => response.json())
    .then(result => {
        console.log('Update task status result:', result);
        if (result.success) {
            // Refresh tasks
            const selectedDate = document.querySelector('.day.selected').dataset.date;
            loadTasks(selectedDate);
        } else {
            console.error('Failed to update task status:', result.error);
        }
    })
    .catch(error => console.error('Error updating task status:', error));
}

// Function to delete task
function deleteTask(taskId) {
    fetch('delete-task.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ id: taskId }),
    })
    .then(response => response.json())
    .then(result => {
        console.log('Delete task result:', result);
        if (result.success) {
            // Refresh tasks
            const selectedDate = document.querySelector('.day.selected').dataset.date;
            loadTasks(selectedDate);
        } else {
            console.error('Failed to delete task:', result.error);
        }
    })
    .catch(error => console.error('Error deleting task:', error));
}



    // Function to generate the calendar
    function generateCalendar(month, year) {
        calendarGrid.innerHTML = ''; // Clear previous calendar

        const firstDay = new Date(year, month, 1).getDay(); // Day of the week for the 1st
        const daysInMonth = new Date(year, month + 1, 0).getDate(); // Number of days in the month

        // Create the day headers
        const dayNames = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
        dayNames.forEach(dayName => {
            const dayElement = document.createElement('div');
            dayElement.className = 'day-name';
            dayElement.textContent = dayName;
            calendarGrid.appendChild(dayElement);
        });

        // Create empty slots before the first day of the current month
        for (let i = 0; i < firstDay; i++) {
            const dayElement = document.createElement('div');
            dayElement.className = 'day empty';
            calendarGrid.appendChild(dayElement);
        }

        // Get today's date
        const today = new Date();
        const todayDate = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;

        // Create the days of the current month
        for (let day = 1; day <= daysInMonth; day++) {
            const dayElement = document.createElement('button');
            const date = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
            
            dayElement.className = date === todayDate ? 'day selected' : 'day'; // Add "selected" class if it's today
            dayElement.dataset.date = date; // Assign the correctly formatted date
            dayElement.textContent = day; // Set the day number as button text
            
            if (date === todayDate) {
                loadTasks(date); // Load tasks for today's date
            }

            calendarGrid.appendChild(dayElement);
        }

        // Create empty slots after the last day of the current month
        const lastDay = new Date(year, month, daysInMonth).getDay();
        for (let i = lastDay + 1; i < 7; i++) {
            const dayElement = document.createElement('div');
            dayElement.className = 'day empty';
            calendarGrid.appendChild(dayElement);
        }

        // Update month and year display
        monthYearSpan.textContent = `${monthNames[month]} ${year}`;
    }

    const monthNames = ["January", "February", "March", "April", "May", "June",
                        "July", "August", "September", "October", "November", "December"];

    // Event listeners for previous and next buttons
    prevMonthBtn.addEventListener('click', function () {
        if (currentMonth === 0) {
            currentMonth = 11;
            currentYear--;
        } else {
            currentMonth--;
        }
        generateCalendar(currentMonth, currentYear);
    });

    nextMonthBtn.addEventListener('click', function () {
        if (currentMonth === 11) {
            currentMonth = 0;
            currentYear++;
        } else {
            currentMonth++;
        }
        generateCalendar(currentMonth, currentYear);
    });

    // Attach event listener to calendar grid for day selection
    calendarGrid.addEventListener('click', function(event) {
        if (event.target.classList.contains('day') && !event.target.classList.contains('empty')) {
            const selectedDate = event.target.dataset.date;
            console.log('Selected date:', selectedDate); // Debugging: log the selected date
            loadTasks(selectedDate); // Load tasks for the selected date

            // Update selected class
            document.querySelectorAll('.day').forEach(day => day.classList.remove('selected'));
            event.target.classList.add('selected');
        }
    });

    // Initialize the calendar
    generateCalendar(currentMonth, currentYear);
});
